I had to add the **icons** folder with three icons that might not exist on older versions of most icons themes. The icons are from the Adwaita icon theme version 3.18.

I had to use the **3.0** folder because the moronic system uses the **2.8** folder on Cinnamon 3.0.x instead of using the files on the root folder.

The **applet.js** files on root folder, **3.0** folder and **3.2** folder are exactly the same and are based on the default applet that comes with Cinnamon 3.2.x.

The **applet.js** file on the **2.8** folder is based on the default applet that comes with Cinnamon 2.8.8.

The **settings-schema.json** files on root folder, **2.8** folder and **3.0** folder are exactly the same.
