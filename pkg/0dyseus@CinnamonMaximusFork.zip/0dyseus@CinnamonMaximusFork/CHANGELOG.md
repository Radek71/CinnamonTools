## Change Log

##### 0.3.5
- Added support for localizations. If someone wants to contribute with translations, inside the Help section of this applet (found in the applet context menu or the Help.md file inside this applet folder) you will find some pointers on how to do it.

##### 0.3.4
- Initial release of the fork.
