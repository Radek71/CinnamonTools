#!/bin/sh
"$@"
exec "$SHELL"
