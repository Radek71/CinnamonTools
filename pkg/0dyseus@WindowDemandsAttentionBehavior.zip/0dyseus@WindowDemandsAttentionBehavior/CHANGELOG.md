## Change Log

##### 1.02
- Added support for localizations. If someone wants to contribute with translations, inside the Help section of this applet (found in the applet context menu or the Help.md file inside this applet folder) you will find some pointers on how to do it.

##### 1.01
- Fixed all broken links pointing to this extension website.

##### 1.00
- Initial release.
